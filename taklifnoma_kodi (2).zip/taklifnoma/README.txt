TO'Y TAKLIFNOMASI — QO'LLANMA
================================

1. Ochish: index.html faylini ikki marta bosing (brauzerda ochiladi).

2. Ma'lumotlarni o'zgartirish:
   index.html ni Bloknot / VS Code bilan oching va
   "SHU YERNI O'ZGARTIRING" degan joyni toping (fayl oxiriga yaqin, <script> ichida).
   Shu yerda:
     groom / bride ............ kuyov va kelin ismi
     groomSurname / brideSurname  familiyalari
     date ..................... to'y sanasi va soati (Toshkent vaqti):
                                "2026-11-14T18:00:00+05:00"
                                yil-oy-kun T soat:daqiqa
     place / address .......... to'yxona nomi va manzil
     hosts .................... kimlar nomidan taklif qilinadi
     text ..................... taklif matni
     program .................. to'y dasturi (vaqt va nomi)
     quiz ..................... o'yin savollari (kelin va kuyov uchun 5 tadan)
     orderPhone / orderTelegram / orderInstagram ... buyurtma uchun aloqa

3. Rasmlar: juftlik rasmlarini "rasm" papkasiga qo'ying va config'da yozing:
     photos:["rasm/1.jpg","rasm/2.jpg","rasm/3.jpg"]

4. Musiqa: mp3 faylni "musiqa" papkasiga qo'ying va yozing:
     music:"musiqa/qoshiq.mp3"

5. Internetga joylash: butun papkani istalgan hostingga yuklang
   (masalan Netlify, GitHub Pages yoki oddiy hosting).
   Yozuv shriftlari internet orqali yuklanadi, internet bo'lmasa oddiy shrift chiqadi.
